#include "cleric.h"

extern int dice(unsigned int, unsigned int, long);


int
clrc_gen(struct class_clrc *p, long idm, WINDOW *mywin){
	int key;
	char displaystr[16];
	char throwoutput[60];
	int x;

	for(x=0; x<6; x++){
		p->stat[x][0]=dice(3, 6, idm);
		p->stat[x][1]=0;
		if(p->stat[x][0]==18)
			p->stat[x][1]=3;
		if(p->stat[x][0]==17||p->stat[x][0]==16)
			p->stat[x][1]=2;
		if(p->stat[x][0]==15||p->stat[x][0]==14||p->stat[x][0]==13)
			p->stat[x][1]=1;
		if(p->stat[x][0]==8||p->stat[x][0]==7||p->stat[x][0]==6)
			p->stat[x][1]=-1;
		if(p->stat[x][0]==5||p->stat[x][0]==4)
			p->stat[x][1]=-2;
		if(p->stat[x][0]==3)
			p->stat[x][1]=-3;
	}
	wclear(mywin);
	snprintf(throwoutput, 59, "strength - %d %d", p->stat[STR][0], p->stat[STR][1]);
	mvwaddstr(mywin, 2, 5, throwoutput);
	snprintf(throwoutput, 59, "intelligence - %d %d", p->stat[INT][0], p->stat[INT][1]);
	mvwaddstr(mywin, 3, 5, throwoutput);
	snprintf(throwoutput, 59, "wisdom - %d %d", p->stat[WIS][0], p->stat[WIS][1]);
	mvwaddstr(mywin, 4, 5, throwoutput);
	snprintf(throwoutput, 59, "dexterity - %d %d", p->stat[DEX][0], p->stat[DEX][1]);
	mvwaddstr(mywin, 5, 5, throwoutput);
	snprintf(throwoutput, 59, "constitution - %d %d", p->stat[CON][0], p->stat[CON][1]);
	mvwaddstr(mywin, 6, 5, throwoutput);
	snprintf(throwoutput, 59, "charisma - %d %d", p->stat[CHA][0], p->stat[CHA][1]);
	mvwaddstr(mywin, 7, 5, throwoutput);
	
	
	mvwaddstr(mywin, 8, 5, "[N||n] discards this roll"); 
	key=wgetch(mywin);
	if(key=='n'||key=='N')
		return 1;
	set_savethrows(p);
	snprintf(throwoutput, 59, "Death Ray/Poison        %d", p->saving_throws[0]);
	mvwaddstr(mywin, 10, 5, throwoutput);
	snprintf(throwoutput, 59, "Magic Wands             %d", p->saving_throws[1]);
	mvwaddstr(mywin, 11, 5, throwoutput);
	snprintf(throwoutput, 59, "Paralysis/Turn to Stone %d", p->saving_throws[2]);
	mvwaddstr(mywin, 12, 5, throwoutput);
	snprintf(throwoutput, 59, "Dragon Breath           %d", p->saving_throws[3]);
	mvwaddstr(mywin, 13, 5, throwoutput);
	snprintf(throwoutput, 59, "Rod/Staff/Spell         %d", p->saving_throws[4]);
	mvwaddstr(mywin, 14, 5, throwoutput);
	p->starting_gp=dice(3, 6, idm);
	p->starting_gp*=10;
	snprintf(throwoutput, 59, "starting gold - %d gp", p->starting_gp);
	mvwaddstr(mywin, 16, 5, throwoutput);
	p->maxhp=dice(1,8, idm);
	p->hit_points=p->maxhp;
	snprintf(throwoutput, 59, "first hit dice maxhp - %d", p->maxhp);
	mvwaddstr(mywin, 17, 5, throwoutput);
	getch();
	return 0;
}


void
set_savethrows(struct class_clrc *p){
	p->saving_throws[0]=11;
	p->saving_throws[1]=12;
	p->saving_throws[2]=14;
	p->saving_throws[3]=16;
	p->saving_throws[4]=15;
	return;
}
