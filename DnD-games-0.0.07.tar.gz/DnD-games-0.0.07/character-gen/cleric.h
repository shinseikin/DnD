#pragma once
#include <curses.h>

#define STR 0
#define INT 1
#define WIS 2
#define DEX 3
#define CON 4
#define CHA 5

#define CLERIC 0x12
#define FIGHTER 0x13
#define MAGICUSER 0x14
#define THIEF 0x15

struct class_clrc{
	int stat[6][2];
	unsigned int class;
	int prime_req;
	unsigned int maxhp;
	unsigned int hit_points;
	unsigned int starting_gp;
	unsigned int pp;
	unsigned int gp;
	unsigned int sp;
	unsigned int ep;
	unsigned int cp;
	unsigned int spellbooks;
	unsigned int equipment_tags[20];
	unsigned int weapon_tags[2];
	unsigned int armor_tag;
	unsigned int sheild;
	int armor_class;
	int thaco;
	int languages;
	char alignment[10];
	char name[50];
	char personality[500];
	char background[500];
	unsigned int sex;
	unsigned int height_tag;
	unsigned int weight_tag; 
	int xp_bonus;
	unsigned int saving_throws[5];
	unsigned int level;
	unsigned long int xp;
	unsigned int spells[7][9]; /* spells db tags */
	unsigned int turn_undead[14];
};


int clrc_gen(struct class_clrc*, long, WINDOW*);
