#include <curses.h>
#include "cleric.h"
#include "fighter.h"
#include "magicuser.h"
#include "thief.h"

int
main(int argc, char *argv[]){
	if(argc!=2)return 1;
	if( (strcmp(argv[1],"cleric") == 0 ){
	} else if( (strcmp(argv[1],"fighter") == 0 ){
	} else if( (strcmp(argv[1],"magicuser") == 0 ){
	} else if( (strcmp(argv[1],"thief") == 0 ){
	} else {
		return 2;
	}
	return 0;
}
