#pragma once
#define __STD_C__

struct stats{
	int str;
	int str_bonus;
	int intel;
	int intel_bonus;
	int wis;
	int dex;
	int con;
	int cha;
};

struct class_strings{
	char clrc[12];
	char fghtr[12];
	char mgcusr[12];
	char thf[12];
};

struct class_cleric{
	struct stats abilities;
	struct class_strings class_set;
	char class_str[12];
	unsigned int class;
	int prime_req;
	unsigned int hit_points;
	unsigned int starting_gp;
	unsigned int pp;
	unsigned int gp;
	unsigned int sp;
	unsigned int ep;
	unsigned int cp;
	unsigned int spellbooks;
	unsigned int equipment_tags[20];
	unsigned int weapons[2];
	unsigned int sheild;
	int armor_class;
	int thaco;
	int languages;
	char alignment[10];
	char name[50];
	char personality[500];
	char background[500];
	unsigned int sex;
	unsigned int height_tag;
	unsigned int weight; 
	int xp_bonus;
	unsigned int saving_throws[5];
	unsigned int level;
	unsigned long int xp;
	unsigned int spells[7][9];
};
