#pragma once
#define __STD_C__

struct stats{
	int str;
	int str_bonus;
	int intel;
	int intel_bonus;
	int wis;
	int wis_bonus;
	int dex;
	int dex_bonus;
	int con;
	int con_bonus;
	int cha;
	int cha_bonus;
};

struct class_strings{
	char clrc[12];
	char fghtr[12];
	char mgcusr[12];
	char thf[12];
};
