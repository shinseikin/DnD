#include "aggregate.h"
#include "cleric.h"

extern int dice(unsigned int, unsigned int, long);

void init(struct class_clrc*);

int
clrc_gen(struct class_clrc *p, long idm, WINDOW *mywin){
	char displaystr[16];
	p->abilities.str=dice(3, 6, idm);
	p->abilities.intel=dice(3, 6, idm);
	p->abilities.wis=dice(3, 6, idm);
	p->abilities.dex=dice(3, 6, idm);
	p->abilities.con=dice(3, 6, idm);
	p->abilities.cha=dice(3, 6, idm);
	p->abilities.str == 18 ? p->abilities.str_bonus=3:waddch(mywin,'.');
	/* str bonus check */
	if(p->abilities.str_bonus == 0)
		p->abilities.str > 15 ? p->abilities.str_bonus=2:waddch(mywin,'.');
	if(p->abilities.str_bonus == 0)
		p->abilities.str > 12 ? p->abilities.str_bonus=1:waddch(mywin,'.');
	if(p->abilities.str_bonus == 0)
		p->abilities.str < 9 && p->abilities.str > 5 ? p->abilities.str_bonus=-1:waddch(mywin,'.');
	if(p->abilities.str_bonus == 0)
		p->abilities.str > 3 ? p->abilities.str_bonus=-2:waddch(mywin,'.');
	if(p->abilities.str_bonus == 0)
		p->abilities.str_bonus=-3;
	/* intel bonus check */
	if(p->abilities.intel_bonus == 0)
		p->abilities.intel > 15 ? p->abilities.intel_bonus=2:waddch(mywin,'.');
	if(p->abilities.intel_bonus == 0)
		p->abilities.intel > 12 ? p->abilities.intel_bonus=1:waddch(mywin,'.');
	if(p->abilities.intel_bonus == 0)
		p->abilities.intel < 9 && p->abilities.intel > 5 ? p->abilities.intel_bonus=-1:waddch(mywin,'.');
	if(p->abilities.intel_bonus == 0)
		p->abilities.intel > 3 ? p->abilities.intel_bonus=-2:waddch(mywin,'.');
	if(p->abilities.intel_bonus == 0)
		p->abilities.intel_bonus=-3;
	/* wis bonus check */
	if(p->abilities.wis_bonus == 0)
		p->abilities.wis > 15 ? p->abilities.wis_bonus=2:waddch(mywin,'.');
	if(p->abilities.wis_bonus == 0)
		p->abilities.wis > 12 ? p->abilities.wis_bonus=1:waddch(mywin,'.');
	if(p->abilities.wis_bonus == 0)
		p->abilities.wis < 9 && p->abilities.wis > 5 ? p->abilities.wis_bonus=-1:waddch(mywin,'.');
	if(p->abilities.wis_bonus == 0)
		p->abilities.wis > 3 ? p->abilities.wis_bonus=-2:waddch(mywin,'.');
	if(p->abilities.wis_bonus == 0)
		p->abilities.wis_bonus=-3;
	/* dex bonus check */
	if(p->abilities.dex_bonus == 0)
		p->abilities.dex > 15 ? p->abilities.dex_bonus=2:waddch(mywin,'.');
	if(p->abilities.dex_bonus == 0)
		p->abilities.dex > 12 ? p->abilities.dex_bonus=1:waddch(mywin,'.');
	if(p->abilities.dex_bonus == 0)
		p->abilities.dex < 9 && p->abilities.dex > 5 ? p->abilities.dex_bonus=-1:waddch(mywin,'.');
	if(p->abilities.dex_bonus == 0)
		p->abilities.dex > 3 ? p->abilities.dex_bonus=-2:waddch(mywin,'.');
	if(p->abilities.dex_bonus == 0)
		p->abilities.dex_bonus=-3;
	/* con bonus check */
	if(p->abilities.con_bonus == 0)
		p->abilities.con > 15 ? p->abilities.con_bonus=2:waddch(mywin,'.');
	if(p->abilities.con_bonus == 0)
		p->abilities.con > 12 ? p->abilities.con_bonus=1:waddch(mywin,'.');
	if(p->abilities.con_bonus == 0)
		p->abilities.con < 9 && p->abilities.con > 5 ? p->abilities.con_bonus=-1:waddch(mywin,'.');
	if(p->abilities.con_bonus == 0)
		p->abilities.con > 3 ? p->abilities.con_bonus=-2:waddch(mywin,'.');
	if(p->abilities.con_bonus == 0)
		p->abilities.con_bonus=-3;
	/* cha bonus check */
	if(p->abilities.cha_bonus == 0)
		p->abilities.cha > 15 ? p->abilities.cha_bonus=2:waddch(mywin,'.');
	if(p->abilities.cha_bonus == 0)
		p->abilities.cha > 12 ? p->abilities.cha_bonus=1:waddch(mywin,'.');
	if(p->abilities.cha_bonus == 0)
		p->abilities.cha < 9 && p->abilities.cha > 5 ? p->abilities.cha_bonus=-1:waddch(mywin,'.');
	if(p->abilities.cha_bonus == 0)
		p->abilities.cha > 3 ? p->abilities.cha_bonus=-2:waddch(mywin,'.');
	if(p->abilities.cha_bonus == 0)
		p->abilities.cha_bonus=-3;
	/* display abilities */
	wclear(mywin);
	snprintf(displaystr, 15, "str %d bonus %d", p->abilities.str, p->abilities.str_bonus);
	mvwaddstr(mywin, 2, 5, displaystr);
	snprintf(displaystr, 15, "int %d bonus %d", p->abilities.intel, p->abilities.intel_bonus);
	mvwaddstr(mywin, 3, 5, displaystr);
	snprintf(displaystr, 15, "wis %d bonus %d", p->abilities.wis, p->abilities.wis_bonus);
	mvwaddstr(mywin, 4, 5, displaystr);
	snprintf(displaystr, 15, "dex %d bonus %d", p->abilities.dex, p->abilities.dex_bonus);
	mvwaddstr(mywin, 5, 5, displaystr);
	snprintf(displaystr, 15, "con %d bonus %d", p->abilities.con, p->abilities.con_bonus);
	mvwaddstr(mywin, 6, 5, displaystr);
	snprintf(displaystr, 15, "cha %d bonus %d", p->abilities.cha, p->abilities.cha_bonus);
	mvwaddstr(mywin, 7, 5, displaystr);
	getch();
	mvwaddstr(mywin, 5, 5, displaystr);

	return 0;
}

void
init(struct class_clrc *p){
	p->abilities.str_bonus=0;
	p->abilities.intel_bonus=0;
	p->abilities.wis_bonus=0;
	p->abilities.dex_bonus=0;
	p->abilities.con_bonus=0;
	p->abilities.cha_bonus=0;
	return;
}
