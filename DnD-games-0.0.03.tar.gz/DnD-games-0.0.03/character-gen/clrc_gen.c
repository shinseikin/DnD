#include "aggregate.h"
#include "cleric.h"

extern int dice(unsigned int, unsigned int, long);

int
clrc_gen(struct class_clrc *p, long idm, WINDOW *mywin){
	return 0;
}

