#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include "aggregate.h"
#include "cleric.h"
/*#include "fighter.h"*/
/*#include "magicuser.h"*/
/*
#include "thief.h"
*/

void print_usage(void);

int
main(int argc, char *argv[]){
	long seed;
	int ctr;
	int run;
	char consolein[12];
	unsigned short len;
	SCREEN *screen;
	WINDOW *win;
	char terminaltype[6];
	struct class_clrc *clericp;

	if(argc!=2){ /* set up the random generator */
		print_usage();
		return 1;
	}
	len=strlen(argv[1]);
	for(ctr=0; ctr<len; ctr++){
		if(isdigit(argv[1][ctr]) == 0){
			print_usage();
			return 2;
		}
	}
	if(len<8){
		print_usage();
		return 3;
	}
	seed=atol(argv[1]);
	if(seed>0)seed=-seed;
	
	snprintf(terminaltype, 5, "%s", "vt100");
	screen=newterm(terminaltype, stdout, stdin); 
	win=initscr();
	run=1;
	while(run){
		wclear(win);
		mvwaddch(win, 5, 2, '>');	
		mvwgetnstr(win, 5, 4, consolein, 11);
		if( (strcmp(consolein, "exit")) == 0 ){
			run=0;
		}
		if( (strcmp(consolein, "cleric")) == 0 ){
			clericp=malloc(sizeof(struct class_clrc));
			if(clericp){
				clrc_gen(clericp, seed, win);
			}
			free(clericp);
		}
		wrefresh(win);
	}
	endwin();
	return 0;
}

void
print_usage(void){
	printf("chrctrgen [8 digit decimal seed]\n");
	return;
}
