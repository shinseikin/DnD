#pragma once
#define __STD_C__

struct stats{
	int str;
	int str_bonus;
	int intel;
	int intel_bonus;
	int wis;
	int dex;
	int con;
	int cha;
};

struct class_strings{
	char clrc[12];
	char fghtr[12];
	char mgcusr[12];
	char thf[12];
};
