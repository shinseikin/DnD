#include <curses.h>
#include "cleric.h"

extern int dice(unsigned int, unsigned int, long);

int
gen_clrc(long seed){
	return 0;
}

