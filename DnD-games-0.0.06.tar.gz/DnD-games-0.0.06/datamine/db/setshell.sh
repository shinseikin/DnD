#!/bin/sh

echo enter date for db creation:
read data
./creatdb $data
LD_LIBRARY_PATH=.; export LD_LIBRARY_PATH
./blitz $data

