#!/bin/sh
touch KEYS.TXT
cc main.c -o blitz -L. -L../lib -lapue_db -lapue -lcurses -I. -I../include
cc creatdb.c -o creatdb -L. -L../lib -lapue_db -lapue -I. -I../include
cc fetch.c -o fetch -L. -L../lib -lapue_db -lapue -I. -I../include
cc editrec.c -o editrec -L. -L../lib -lapue_db -lapue -I. -I../include
cc newrec.c -o newrec -L. -L../lib -lapue_db -lapue -I. -I../include
cc linerec.c -o linerec -L. -L../lib -lapue_db -lapue -I. -I../include
cc line_edit.c -o line_edit -L. -L../lib -lapue_db -lapue -I. -I../include


