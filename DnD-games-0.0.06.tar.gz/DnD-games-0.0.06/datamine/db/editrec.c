#include "apue.h"
#include "apue_db.h"
#include <fcntl.h>
#include <stdio.h>
#include <time.h>

int
main(int argc, char *argv[]){
	DBHANDLE	db;
	char		data[10][85];
	char		collect[1000];
	char		mychar;
	int		index;
	int		ctr;
	time_t		secs;
	struct tm 	*p;
	if (argc != 2)				
		exit(1);

	if ((db = db_open("db4", O_RDWR, FILE_MODE)) == NULL)
		err_sys("db_open error")			;
	
	index=0;

	for(ctr=0; ctr<1000; ctr++)
		collect[ctr]=NULL;
	secs=time(&secs);
	p=localtime(&secs);
	strftime(collect, 6, "%H:%M\n", p);

	while( index<10 ){
		read(1, &data[index], 80);
		strcat(	collect, data[index]);
		index++;
	}
	if (db_store(db, argv[1], collect, DB_REPLACE) != 0)
		err_quit("db_store error for newrec");
	
	db_close(db);
	exit(0);
}
