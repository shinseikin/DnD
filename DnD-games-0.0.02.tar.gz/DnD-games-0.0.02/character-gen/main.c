#include <curses.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include "aggregate.h"
#include "cleric.h"
/*#include "fighter.h"*/
/*#include "magicuser.h"*/
/*
#include "thief.h"
*/

void print_usage(void);

int
main(int argc, char *argv[]){
	long seed;
	int ctr;
	unsigned short len;
	SCREEN *screen;
	WINDOW *win;
	char terminaltype[6];

	if(argc!=2){ /* set up the random generator */
		print_usage();
		return 1;
	}
	len=strlen(argv[1]);
	for(ctr=0; ctr<len; ctr++){
		if(isdigit(argv[1][ctr]) == 0){
			print_usage();
			return 2;
		}
	}
	if(len<8){
		print_usage();
		return 3;
	}
	seed=atol(argv[1]);
	if(seed>0)seed=-seed;
	
	snprintf(terminaltype, 5, "%s", "vt100");
	screen=newterm(terminaltype, stdout, stdin); 
	win=initscr();

	endwin();
	return 0;
}

void
print_usage(void){
	printf("chrctrgen [8 digit decimal seed]\n");
	return;
}
