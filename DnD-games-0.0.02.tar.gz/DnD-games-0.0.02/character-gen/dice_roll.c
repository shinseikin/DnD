#include <stdlib.h>

int
dice(unsigned int num, unsigned int sided, long seed){
	unsigned int collected_sum;
	int ctr;

	collected_sum=0;
	srandom(seed);
	for(ctr=0; ctr<num; ctr++){
		collected_sum+=(random() % sided);
	}
	return collected_sum;
}
